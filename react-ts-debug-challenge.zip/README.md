# DevShelf — React + TypeScript Debug Challenge

A small project directory built with React, TypeScript, Vite, and CSS Modules. The app should run, but several features intentionally behave incorrectly.

## Run locally

Requirements: Node.js 18+ and npm.

```bash
npm install
npm run dev
```

Open the local URL printed by Vite.

To check the production build:

```bash
npm run build
```

## Your task

Fix the bugs without removing the existing UI or changing the intended product behavior.

### Feature checklist
- [ ] Searching should match project names **and descriptions**, ignoring letter case and surrounding whitespace.
- [ ] Category filters should show projects in the selected category.
- [ ] “Favorites only” should show only favorited projects.
- [ ] Clicking a star should toggle that project's favorite state.
- [ ] “Recently updated” should list newest projects first.
- [ ] “Most stars” should list projects with the highest star count first.
- [ ] “Clear filters” should reset all filtering controls.
- [ ] The result count should always match the visible cards.

### Constraints
- Keep TypeScript strict; avoid `any`.
- Keep component styles in CSS Modules.
- Prefer small, focused changes.
- Don't replace the app with a new implementation.

### Suggested workflow
1. Run the app and try every control.
2. Reproduce each issue before changing code.
3. Fix one behavior at a time.
4. Run `npm run build` and manually retest the checklist.

There are several logic bugs, not intentionally broken dependencies. Some defects can interact with each other, so test combinations of search, category, favorites, and sorting.
